# JutsuAutoClicker 1.2

App Android experimental para ler a sequência de selos do minijogo e executar os toques em ordem.

## Como funciona

1. Ative o serviço de acessibilidade do JutsuAutoClicker.
2. Permita a sobreposição/painel flutuante.
3. Toque em **Iniciar Auto Jutsu** e aceite a captura de tela.
4. Abra o jogo. O painel flutuante mostra a sequência reconhecida.
5. Antes de executar, o mesmo resultado precisa aparecer em 2 capturas OCR consecutivas.
6. Depois dos selos, o app toca na área de lançamento configurada.

## Verificação

O detector aceita somente V, B, Z, X, C e N e tenta corrigir algumas confusões comuns do OCR. O projeto separa a validação em `SealDetector` para que a lógica possa ser testada sem depender da tela.

## Calibração

A posição inicial dos selos foi ajustada a partir da captura 1536x691 fornecida durante o desenvolvimento. No painel flutuante, X-/X+/Y-/Y+ permitem corrigir o deslocamento do seu aparelho. O botão ↺ restaura o padrão.

## GitHub Actions

O workflow em `.github/workflows/build-apk.yml` compila com Java 17 e Gradle 8.11.1. Ele funciona tanto com o projeto extraído diretamente no repositório quanto com um ZIP `JutsuAutoClicker*.zip`.

## Limitação do teste

A compilação e os testes da lógica são automatizados, mas o toque físico no Roblox precisa ser validado no aparelho real, pois coordenadas, barras do sistema e escala podem variar.
