# JutsuAutoClicker 1.2

App Android experimental para ler a sequência de selos do minijogo e executar os toques em ordem.

## Como funciona

1. Ative o serviço de acessibilidade do JutsuAutoClicker.
2. Permita a sobreposição/painel flutuante.
3. Toque em **Iniciar Auto Jutsu** e aceite a captura de tela.
4. Abra o jogo. O painel flutuante mostra a sequência reconhecida.
5. Antes de executar, o mesmo resultado precisa aparecer em 2 capturas OCR consecutivas.
6. Depois dos selos, o app toca na área de lançamento configurada.

## Verificação

O detector aceita somente V, B, Z, X, C e N e tenta corrigir algumas confusões comuns do OCR. O projeto separa a validação em `SealDetector` para que a lógica possa ser testada sem depender da tela.

## Calibração

A posição inicial dos selos foi ajustada a partir da captura 1536x691 fornecida durante o desenvolvimento. No painel flutuante, X-/X+/Y-/Y+ permitem corrigir o deslocamento do seu aparelho. O botão ↺ restaura o padrão.

## GitHub Actions

O workflow em `.github/workflows/build-apk.yml` compila com Java 17 e Gradle 8.11.1. Ele funciona tanto com o projeto extraído diretamente no repositório quanto com um ZIP `JutsuAutoClicker*.zip`.

## Limitação do teste

A compilação e os testes da lógica são automatizados, mas o toque físico no Roblox precisa ser validado no aparelho real, pois coordenadas, barras do sistema e escala podem variar.


## v1.3 — Visor OCR e marcadores visuais

- Visor transparente reposicionável e redimensionável para delimitar exatamente a área da sequência.
- Botão **Visor: EDITAR/TRAVADO**: edite durante a configuração e trave antes de jogar.
- Mostra no painel o texto bruto que o OCR realmente enxergou e a sequência validada.
- Seis marcadores circulares Z/V/X/B/C/N sobre os pontos de toque, que podem ser ocultados.
- A posição do visor fica salva no aparelho.
- O clique continua sendo feito por AccessibilityService nos pontos da tela; Android não oferece uma forma confiável de injetar teclas arbitrárias de teclado em outro app usando apenas AccessibilityService, então o modo por coordenadas é o caminho mais compatível.

### Como usar o visor

1. Inicie a captura.
2. Arraste o retângulo **VISOR OCR** até cobrir somente a sequência, por exemplo `VBZXZV`.
3. Arraste o ponto verde do canto inferior direito para ajustar o tamanho.
4. Toque em **Visor: EDITAR** para travar.
5. Observe `OCR viu:` e `Detectado:` no painel.
6. Quando `Detectado:` mostrar a sequência correta, o serviço de acessibilidade executa os selos em ordem.

O visor é apenas uma área visual de calibração; o OCR usa as mesmas coordenadas salvas mesmo quando o visor está travado.
