package com.jutsu.autoclicker;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.view.View;

/** Fundo leve desenhado em código: textura, brilho e padrão de selo sem imagens grandes. */
public class TextureBackgroundView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);

    public TextureBackgroundView(Context context) {
        super(context);
        line.setStrokeWidth(dp(1));
        setWillNotDraw(false);
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth(), h = getHeight();
        paint.setShader(new LinearGradient(0, 0, w, h,
                Color.rgb(8, 8, 20), Color.rgb(20, 8, 30), Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, w, h, paint);
        paint.setShader(null);

        // Grades diagonais suaves.
        line.setColor(Color.argb(18, 180, 105, 255));
        for (float x = -h; x < w + h; x += dp(46)) {
            canvas.drawLine(x, 0, x + h, h, line);
        }

        // Pontos da textura.
        paint.setColor(Color.argb(18, 255, 255, 255));
        float step = dp(24);
        for (float y = 0; y < h; y += step) {
            for (float x = 0; x < w; x += step) {
                float jitter = ((int)(x / step) + (int)(y / step)) % 2 == 0 ? 0 : dp(5);
                canvas.drawCircle(x + jitter, y + jitter, dp(0.7f), paint);
            }
        }

        // Emblema grande quase invisível.
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(dp(2));
        line.setColor(Color.argb(24, 255, 40, 85));
        float cx = w * 0.82f, cy = h * 0.18f;
        canvas.drawCircle(cx, cy, dp(120), line);
        canvas.drawCircle(cx, cy, dp(88), line);
        canvas.drawLine(cx - dp(70), cy, cx + dp(70), cy, line);
        canvas.drawLine(cx, cy - dp(70), cx, cy + dp(70), line);
        line.setStyle(Paint.Style.FILL);
    }
}
