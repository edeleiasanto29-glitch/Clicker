package com.jutsu.autoclicker;

import android.content.Context;
import android.content.SharedPreferences;

/** Configurações persistentes do app. */
public final class AppSettings {
    private static final String PREFS = "jutsu_settings";
    private static final String KEY_GAP = "gap_ms";
    private static final String KEY_LAUNCH = "launch_delay_ms";
    private static final String KEY_PAUSED = "paused";
    private static final String KEY_OX = "seal_offset_x";
    private static final String KEY_OY = "seal_offset_y";
    private static final String KEY_LX = "launch_x";
    private static final String KEY_LY = "launch_y";

    public static final int DEFAULT_GAP = 20;
    public static final int DEFAULT_LAUNCH_DELAY = 120;
    public static final float DEFAULT_OX = 0f;
    public static final float DEFAULT_OY = 0f;
    public static final float DEFAULT_LX = 0.50f;
    public static final float DEFAULT_LY = 0.68f;

    private AppSettings() {}

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static int getGap(Context c) {
        return prefs(c).getInt(KEY_GAP, DEFAULT_GAP);
    }

    public static void setGap(Context c, int value) {
        prefs(c).edit().putInt(KEY_GAP, clamp(value, 8, 120)).apply();
    }

    public static int getLaunchDelay(Context c) {
        return prefs(c).getInt(KEY_LAUNCH, DEFAULT_LAUNCH_DELAY);
    }

    public static void setLaunchDelay(Context c, int value) {
        prefs(c).edit().putInt(KEY_LAUNCH, clamp(value, 30, 1000)).apply();
    }

    public static boolean isPaused(Context c) {
        return prefs(c).getBoolean(KEY_PAUSED, false);
    }

    public static void setPaused(Context c, boolean paused) {
        prefs(c).edit().putBoolean(KEY_PAUSED, paused).apply();
    }

    public static float getOffsetX(Context c) {
        return prefs(c).getFloat(KEY_OX, DEFAULT_OX);
    }

    public static void setOffsetX(Context c, float value) {
        prefs(c).edit().putFloat(KEY_OX, clamp(value, -0.08f, 0.08f)).apply();
    }

    public static float getOffsetY(Context c) {
        return prefs(c).getFloat(KEY_OY, DEFAULT_OY);
    }

    public static void setOffsetY(Context c, float value) {
        prefs(c).edit().putFloat(KEY_OY, clamp(value, -0.10f, 0.10f)).apply();
    }

    public static float getLaunchX(Context c) {
        return prefs(c).getFloat(KEY_LX, DEFAULT_LX);
    }

    public static void setLaunchX(Context c, float value) {
        prefs(c).edit().putFloat(KEY_LX, clamp(value, 0.25f, 0.75f)).apply();
    }

    public static float getLaunchY(Context c) {
        return prefs(c).getFloat(KEY_LY, DEFAULT_LY);
    }

    public static void setLaunchY(Context c, float value) {
        prefs(c).edit().putFloat(KEY_LY, clamp(value, 0.45f, 0.88f)).apply();
    }

    public static void resetCalibration(Context c) {
        prefs(c).edit()
                .putFloat(KEY_OX, DEFAULT_OX)
                .putFloat(KEY_OY, DEFAULT_OY)
                .putFloat(KEY_LX, DEFAULT_LX)
                .putFloat(KEY_LY, DEFAULT_LY)
                .apply();
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
