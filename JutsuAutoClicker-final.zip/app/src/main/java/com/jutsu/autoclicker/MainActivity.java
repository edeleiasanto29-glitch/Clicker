package com.jutsu.autoclicker;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

/** Tela principal do Jutsu Auto Clicker. */
public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 4001;
    private static final int REQ_NOTIFICATIONS = 4002;
    private TextView status;
    private TextView speed;
    private TextView launchDelay;
    private TextView permissionState;
    private SeekBar speedBar;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        refreshUi();
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable card(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), stroke);
        return d;
    }

    private TextView text(String value, float size) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(Color.WHITE);
        t.setTextSize(size);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    private Button actionButton(String value, boolean primary) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextColor(Color.WHITE);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setMinHeight(dp(48));
        b.setPadding(dp(12), 0, dp(12), 0);
        b.setBackground(card(primary ? Color.rgb(185, 25, 62) : Color.rgb(28, 23, 52),
                13, primary ? Color.rgb(255, 70, 105) : Color.rgb(92, 70, 150)));
        return b;
    }

    private void buildUi() {
        FrameLayout background = new FrameLayout(this);
        background.addView(new TextureBackgroundView(this), new FrameLayout.LayoutParams(-1, -1));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), dp(18), dp(18), dp(26));
        scroll.addView(content);
        background.addView(scroll, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(8), dp(8), dp(8), dp(8));
        header.setBackground(card(Color.argb(230, 12, 10, 26), 18, Color.rgb(91, 65, 160)));

        SealLogoView logo = new SealLogoView(this);
        header.addView(logo, new LinearLayout.LayoutParams(dp(72), dp(72)));
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView title = text("JutsuAutoClicker", 25);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        TextView subtitle = text("OCR + selos automáticos  •  v1.2", 12);
        subtitle.setTextColor(Color.rgb(204, 182, 238));
        titles.addView(title, new LinearLayout.LayoutParams(-1, dp(38)));
        titles.addView(subtitle, new LinearLayout.LayoutParams(-1, dp(26)));
        header.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));
        content.addView(header, new LinearLayout.LayoutParams(-1, -2));

        status = text("Status: verificando…", 14);
        status.setPadding(dp(14), dp(10), dp(14), dp(10));
        status.setBackground(card(Color.argb(205, 13, 12, 31), 13, Color.rgb(76, 58, 126)));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, dp(62));
        sp.topMargin = dp(12);
        content.addView(status, sp);

        TextView setup = text("1  PERMISSÕES", 12);
        setup.setTextColor(Color.rgb(222, 190, 255));
        setup.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams setupLp = new LinearLayout.LayoutParams(-1, dp(34));
        setupLp.topMargin = dp(12);
        content.addView(setup, setupLp);

        LinearLayout permCard = new LinearLayout(this);
        permCard.setOrientation(LinearLayout.VERTICAL);
        permCard.setPadding(dp(12), dp(8), dp(12), dp(8));
        permCard.setBackground(card(Color.argb(220, 13, 12, 31), 15, Color.rgb(72, 55, 122)));

        Button access = actionButton("⚡  Ativar Acessibilidade", false);
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        permCard.addView(access, new LinearLayout.LayoutParams(-1, dp(48)));

        Button overlay = actionButton("◈  Permitir painel flutuante", false);
        overlay.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= 23) {
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName())));
                } catch (Throwable ignored) {
                    startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
                }
            }
        });
        LinearLayout.LayoutParams ovlp = new LinearLayout.LayoutParams(-1, dp(48));
        ovlp.topMargin = dp(7);
        permCard.addView(overlay, ovlp);

        permissionState = text("", 11);
        permissionState.setTextColor(Color.LTGRAY);
        permissionState.setPadding(dp(8), dp(5), dp(8), dp(5));
        permCard.addView(permissionState, new LinearLayout.LayoutParams(-1, dp(40)));
        LinearLayout.LayoutParams pc = new LinearLayout.LayoutParams(-1, -2);
        content.addView(permCard, pc);

        TextView tuning = text("2  VELOCIDADE", 12);
        tuning.setTextColor(Color.rgb(222, 190, 255));
        tuning.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(-1, dp(34));
        tlp.topMargin = dp(12);
        content.addView(tuning, tlp);

        LinearLayout tuneCard = new LinearLayout(this);
        tuneCard.setOrientation(LinearLayout.VERTICAL);
        tuneCard.setPadding(dp(12), dp(8), dp(12), dp(10));
        tuneCard.setBackground(card(Color.argb(220, 13, 12, 31), 15, Color.rgb(72, 55, 122)));

        speed = text("Intervalo: --", 13);
        tuneCard.addView(speed, new LinearLayout.LayoutParams(-1, dp(30)));
        speedBar = new SeekBar(this);
        speedBar.setMax(112);
        speedBar.setProgress(Math.max(0, Math.min(112, AppSettings.getGap(this) - 8)));
        speedBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                AppSettings.setGap(MainActivity.this, progress + 8);
                refreshUi();
            }
            @Override public void onStartTrackingTouch(SeekBar bar) { }
            @Override public void onStopTrackingTouch(SeekBar bar) { }
        });
        tuneCard.addView(speedBar, new LinearLayout.LayoutParams(-1, dp(42)));

        launchDelay = text("Atraso: --", 13);
        tuneCard.addView(launchDelay, new LinearLayout.LayoutParams(-1, dp(30)));
        LinearLayout presets = new LinearLayout(this);
        presets.setOrientation(LinearLayout.HORIZONTAL);
        addPreset(presets, "Rápido", 12, 70);
        addPreset(presets, "Seguro", 25, 120);
        addPreset(presets, "Lento", 45, 180);
        tuneCard.addView(presets, new LinearLayout.LayoutParams(-1, dp(48)));
        content.addView(tuneCard, new LinearLayout.LayoutParams(-1, -2));

        TextView runTitle = text("3  INICIAR", 12);
        runTitle.setTextColor(Color.rgb(222, 190, 255));
        runTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(-1, dp(34));
        rlp.topMargin = dp(12);
        content.addView(runTitle, rlp);

        Button start = actionButton("▶  INICIAR AUTO JUTSU", true);
        start.setOnClickListener(v -> requestCapture());
        content.addView(start, new LinearLayout.LayoutParams(-1, dp(54)));

        Button stop = actionButton("■  PARAR", false);
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, CaptureService.class));
            AppSettings.setPaused(this, true);
            refreshUi();
        });
        LinearLayout.LayoutParams stopLp = new LinearLayout.LayoutParams(-1, dp(48));
        stopLp.topMargin = dp(7);
        content.addView(stop, stopLp);

        TextView helpTitle = text("4  VERIFICAÇÃO E TESTES", 12);
        helpTitle.setTextColor(Color.rgb(222, 190, 255));
        helpTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams htlp = new LinearLayout.LayoutParams(-1, dp(34));
        htlp.topMargin = dp(12);
        content.addView(helpTitle, htlp);

        LinearLayout help = new LinearLayout(this);
        help.setOrientation(LinearLayout.VERTICAL);
        help.setPadding(dp(14), dp(12), dp(14), dp(12));
        help.setBackground(card(Color.argb(200, 13, 12, 31), 15, Color.rgb(72, 55, 122)));
        TextView helpText = text(
                "O leitor aceita somente V, B, Z, X, C e N.\n" +
                "Antes de clicar, a mesma sequência precisa ser reconhecida em 2 capturas.\n" +
                "No painel flutuante existem testes individuais dos 6 selos, lançamento e calibração X/Y.", 12);
        helpText.setGravity(Gravity.TOP);
        helpText.setTextColor(Color.LTGRAY);
        help.addView(helpText, new LinearLayout.LayoutParams(-1, dp(92)));
        content.addView(help, new LinearLayout.LayoutParams(-1, -2));

        TextView footer = text("Dica: deixe o jogo na orientação usada na calibração inicial.\nAjuste X/Y no painel se os selos do seu aparelho estiverem deslocados.", 10);
        footer.setTextColor(Color.GRAY);
        footer.setPadding(dp(4), dp(12), dp(4), 0);
        content.addView(footer, new LinearLayout.LayoutParams(-1, dp(58)));

        setContentView(background);
        refreshUi();
    }

    private void addPreset(LinearLayout row, String label, int gap, int launch) {
        Button b = actionButton(label, false);
        b.setTextSize(11);
        b.setOnClickListener(v -> {
            AppSettings.setGap(this, gap);
            AppSettings.setLaunchDelay(this, launch);
            if (speedBar != null) speedBar.setProgress(gap - 8);
            refreshUi();
        });
        row.addView(b, new LinearLayout.LayoutParams(0, dp(44), 1));
    }

    private void refreshUi() {
        boolean access = TapAccessibilityService.instance != null;
        boolean overlay = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
        boolean running = isServiceRunningHint();
        if (status == null) return;
        status.setText((running ? "● RODANDO" : "○ PARADO") +
                "\nAcessibilidade: " + (access ? "ATIVA" : "não conectada") +
                "  •  Painel: " + (overlay ? "OK" : "bloqueado"));
        status.setTextColor(running ? Color.rgb(110, 255, 150) : Color.WHITE);

        if (permissionState != null) {
            permissionState.setText("Acessibilidade: " + (access ? "✓" : "—") +
                    "    Sobreposição: " + (overlay ? "✓" : "—"));
        }
        if (speed != null) speed.setText("Intervalo entre selos: " + AppSettings.getGap(this) + " ms");
        if (launchDelay != null) launchDelay.setText("Atraso antes de lançar: " + AppSettings.getLaunchDelay(this) + " ms");
    }

    private boolean isServiceRunningHint() {
        return TapAccessibilityService.instance != null && !AppSettings.isPaused(this);
    }

    private void requestCapture() {
        if (TapAccessibilityService.instance == null) {
            Toast.makeText(this, "Ative o serviço em Acessibilidade e volte ao app.", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Permita o painel flutuante para controlar o app durante o jogo.", Toast.LENGTH_LONG).show();
            return;
        }

        AppSettings.setPaused(this, false);
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        if (manager == null) {
            Toast.makeText(this, "MediaProjection não está disponível neste aparelho.", Toast.LENGTH_LONG).show();
            return;
        }
        // Um consentimento novo é solicitado a cada sessão, como exigido pelo Android 14+.
        startActivityForResult(manager.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_CAPTURE) return;
        if (resultCode == RESULT_OK && data != null) {
            Intent service = new Intent(this, CaptureService.class);
            service.putExtra("resultCode", resultCode);
            service.putExtra("data", data);
            try {
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(service);
                else startService(service);
                refreshUi();
            } catch (Throwable t) {
                Toast.makeText(this, "Não foi possível iniciar a captura: " + t.getMessage(), Toast.LENGTH_LONG).show();
            }
        } else {
            AppSettings.setPaused(this, true);
            Toast.makeText(this, "Captura cancelada.", Toast.LENGTH_SHORT).show();
        }
    }
}
