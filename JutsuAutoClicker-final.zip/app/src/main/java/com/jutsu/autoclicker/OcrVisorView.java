package com.jutsu.autoclicker;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/** Visor transparente, arrastável e redimensionável para delimitar a área do OCR. */
public class OcrVisorView extends View {
    public interface Listener {
        void onMoveDelta(int dx, int dy);
        void onResizeDelta(int dw, int dh);
    }

    private final Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint handle = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Listener listener;
    private float downX, downY;
    private boolean resizing;
    private int lastDx, lastDy;

    public OcrVisorView(Context context) {
        super(context);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        border.setStyle(Paint.Style.STROKE);
        border.setStrokeWidth(dp(2));
        border.setColor(Color.rgb(80, 255, 160));
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(Color.argb(18, 80, 255, 160));
        text.setColor(Color.WHITE);
        text.setTextSize(dp(12));
        text.setShadowLayer(dp(3), 0, 1, Color.BLACK);
        handle.setColor(Color.rgb(80, 255, 160));
        setClickable(true);
        setWillNotDraw(false);
    }

    public void setListener(Listener listener) { this.listener = listener; }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = Math.max(4, getWidth() - 2);
        float h = Math.max(4, getHeight() - 2);
        RectF r = new RectF(2, 2, w, h);
        canvas.drawRoundRect(r, dp(10), dp(10), fill);
        canvas.drawRoundRect(r, dp(10), dp(10), border);
        canvas.drawText("VISOR OCR", dp(9), dp(17), text);
        canvas.drawText("arraste • ↘ redimensione", dp(9), dp(33), text);
        canvas.drawCircle(getWidth() - dp(10), getHeight() - dp(10), dp(8), handle);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getRawX();
                downY = e.getRawY();
                lastDx = 0;
                lastDy = 0;
                resizing = e.getX() > getWidth() - dp(42) && e.getY() > getHeight() - dp(42);
                return true;
            case MotionEvent.ACTION_MOVE:
                int totalDx = Math.round(e.getRawX() - downX);
                int totalDy = Math.round(e.getRawY() - downY);
                int stepX = totalDx - lastDx;
                int stepY = totalDy - lastDy;
                lastDx = totalDx;
                lastDy = totalDy;
                if (listener != null) {
                    if (resizing) listener.onResizeDelta(stepX, stepY);
                    else listener.onMoveDelta(stepX, stepY);
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                return true;
            default:
                return true;
        }
    }

    private float dp(float v) { return v * getResources().getDisplayMetrics().density; }
}
