package com.jutsu.autoclicker;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/** Visor transparente para posicionar manualmente a área que será lida pelo OCR. */
public class OcrVisorView extends View {
    public interface Listener {
        void onMoveDelta(int dx, int dy);
        void onResizeDelta(int dw, int dh);
    }

    private final Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Listener listener;
    private float downX, downY;
    private int startW, startH;
    private boolean resizing;

    public OcrVisorView(Context context) {
        super(context);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        border.setStyle(Paint.Style.STROKE);
        border.setStrokeWidth(dp(2));
        border.setColor(Color.rgb(80, 255, 160));
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(Color.argb(18, 80, 255, 160));
        text.setColor(Color.WHITE);
        text.setTextSize(dp(12));
        text.setShadowLayer(dp(3), 0, 1, Color.BLACK);
        setWillNotDraw(false);
    }

    public void setListener(Listener listener) { this.listener = listener; }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        RectF r = new RectF(2, 2, getWidth() - 2, getHeight() - 2);
        canvas.drawRoundRect(r, dp(10), dp(10), fill);
        canvas.drawRoundRect(r, dp(10), dp(10), border);
        canvas.drawText("VISOR OCR • arraste", dp(10), dp(17), text);
        Paint handle = new Paint(Paint.ANTI_ALIAS_FLAG);
        handle.setColor(Color.rgb(80, 255, 160));
        canvas.drawCircle(getWidth() - dp(9), getHeight() - dp(9), dp(7), handle);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
            downX = e.getRawX(); downY = e.getRawY();
            startW = getWidth(); startH = getHeight();
            resizing = e.getX() > getWidth() - dp(35) && e.getY() > getHeight() - dp(35);
            return true;
        }
        if (e.getActionMasked() == MotionEvent.ACTION_MOVE) {
            float dx = e.getRawX() - downX;
            float dy = e.getRawY() - downY;
            if (listener != null) {
                if (resizing) {
                    listener.onResizeDelta((int) dx, (int) dy);
                } else {
                    listener.onMoveDelta((int) dx, (int) dy);
                }
            }
            return true;
        }
        return true;
    }

    private float dp(float v) { return v * getResources().getDisplayMetrics().density; }
}
