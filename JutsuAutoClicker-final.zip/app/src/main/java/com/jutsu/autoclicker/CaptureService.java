package com.jutsu.autoclicker;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.nio.ByteBuffer;
import java.util.Locale;

/** Captura a tela, valida a sequência OCR e envia os selos em ordem. */
public class CaptureService extends Service {
    private static final String CHANNEL = "jutsu_auto";
    private static final int NOTIFICATION_ID = 9;

    // O visor OCR é configurável pelo usuário e salvo em coordenadas normalizadas.

    private static final int STABLE_FRAMES = 2;
    private static final long ABSENCE_RESET_MS = 650L;

    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private TextRecognizer recognizer;
    private Handler handler;
    private WindowManager windowManager;

    private LinearLayout overlayRoot;
    private TextView overlayStatus;
    private TextView overlaySequence;
    private TextView overlayOcr;
    private TextView overlaySpeed;
    private TextView overlayLaunch;
    private TextView overlayCalibration;
    private Button pauseButton;
    private Button visorButton;
    private WindowManager.LayoutParams overlayParams;
    private OcrVisorView visorView;
    private WindowManager.LayoutParams visorParams;
    private SealMarkerView markerView;
    private WindowManager.LayoutParams markerParams;
    private boolean visorEditing = true;
    private boolean markersVisible = true;

    private boolean overlayExpanded = true;
    private boolean busy = false;
    private String candidateSequence = "";
    private int candidateHits = 0;
    private String lastAcceptedSequence = "";
    private long lastAcceptedSeenAt = 0L;
    private long cycleBusyUntil = 0L;
    private int width = 0;
    private int height = 0;
    private MediaProjection.Callback projectionCallback;

    @Override public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        createChannel();
        promoteToForeground("Preparando captura…");
        if (intent == null) return START_NOT_STICKY;

        int result = intent.getIntExtra("resultCode", android.app.Activity.RESULT_CANCELED);
        Intent data;
        if (Build.VERSION.SDK_INT >= 33) {
            data = intent.getParcelableExtra("data", Intent.class);
        } else {
            //noinspection deprecation
            data = intent.getParcelableExtra("data");
        }

        if (result == android.app.Activity.RESULT_OK && data != null) {
            safeStartCapture(data);
        } else {
            showStatus("Captura não autorizada");
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void safeStartCapture(Intent data) {
        try {
            stopCaptureOnly();
            MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = manager.getMediaProjection(android.app.Activity.RESULT_OK, data);
            if (projection == null) throw new IllegalStateException("MediaProjection nula");

            projectionCallback = new MediaProjection.Callback() {
                @Override public void onStop() {
                    handler.post(() -> {
                        stopCaptureOnly();
                        showStatus("Captura encerrada pelo Android");
                    });
                }
            };
            projection.registerCallback(projectionCallback, handler);

            android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
            width = Math.max(1, dm.widthPixels);
            height = Math.max(1, dm.heightPixels);
            reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
            display = projection.createVirtualDisplay(
                    "JutsuAutoClicker",
                    width, height, dm.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    reader.getSurface(), null, handler);

            reader.setOnImageAvailableListener(this::handleFrame, handler);
            showOverlay();
            showOcrVisor();
            showSealMarkers();
            showStatus("Posicione o VISOR sobre a sequência…");
        } catch (Throwable t) {
            showStatus("Erro ao iniciar captura: " + safeMessage(t));
            stopCaptureOnly();
            stopSelf();
        }
    }

    private void handleFrame(ImageReader source) {
        Image image = null;
        try {
            image = source.acquireLatestImage();
            if (image == null) return;
            if (AppSettings.isPaused(this) || busy) return;
            busy = true;
            Bitmap full = imageToBitmap(image);
            analyze(full);
        } catch (Throwable t) {
            busy = false;
        } finally {
            if (image != null) image.close();
        }
    }

    private Bitmap imageToBitmap(Image image) {
        int iw = image.getWidth();
        int ih = image.getHeight();
        Image.Plane plane = image.getPlanes()[0];
        ByteBuffer buffer = plane.getBuffer();
        int pixelStride = plane.getPixelStride();
        int rowStride = plane.getRowStride();
        int rowPadding = Math.max(0, rowStride - pixelStride * iw);
        int paddedWidth = iw + (pixelStride == 0 ? 0 : rowPadding / pixelStride);

        Bitmap full = Bitmap.createBitmap(paddedWidth, ih, Bitmap.Config.ARGB_8888);
        buffer.rewind();
        full.copyPixelsFromBuffer(buffer);
        Bitmap cropped = Bitmap.createBitmap(full, 0, 0, iw, ih);
        full.recycle();
        width = iw;
        height = ih;
        return cropped;
    }

    private void analyze(Bitmap full) {
        int left = clamp((int) (width * AppSettings.getOcrLeft(this)), 0, Math.max(0, width - 2));
        int top = clamp((int) (height * AppSettings.getOcrTop(this)), 0, Math.max(0, height - 2));
        int right = clamp((int) (width * AppSettings.getOcrRight(this)), left + 2, width);
        int bottom = clamp((int) (height * AppSettings.getOcrBottom(this)), top + 2, height);

        Bitmap crop = null;
        Bitmap scaled = null;
        try {
            crop = Bitmap.createBitmap(full, left, top, right - left, bottom - top);
            scaled = Bitmap.createScaledBitmap(crop, crop.getWidth() * 2, crop.getHeight() * 2, true);
            crop.recycle();
            crop = null;
            full.recycle();
            final Bitmap input = scaled;

            recognizer.process(InputImage.fromBitmap(input, 0))
                    .addOnSuccessListener(text -> handleOcrResult(SealDetector.findSequence(text), text.getText()))
                    .addOnFailureListener(e -> { /* próxima captura tenta novamente */ })
                    .addOnCompleteListener(task -> {
                        if (!input.isRecycled()) input.recycle();
                        busy = false;
                    });
        } catch (Throwable t) {
            if (crop != null && !crop.isRecycled()) crop.recycle();
            if (scaled != null && !scaled.isRecycled()) scaled.recycle();
            if (!full.isRecycled()) full.recycle();
            busy = false;
        }
    }

    private void handleOcrResult(String sequence, String rawOcr) {
        long now = System.currentTimeMillis();
        overlayOcr(rawOcr);
        if (sequence == null || !SealDetector.isValid(sequence)) {
            if (now - lastAcceptedSeenAt > ABSENCE_RESET_MS) lastAcceptedSequence = "";
            if (now - lastAcceptedSeenAt > 260) {
                candidateSequence = "";
                candidateHits = 0;
            }
            return;
        }

        if (sequence.equals(candidateSequence)) {
            candidateHits++;
        } else {
            candidateSequence = sequence;
            candidateHits = 1;
        }

        overlaySequence(sequence);
        if (sequence.equals(lastAcceptedSequence)) {
            lastAcceptedSeenAt = now;
            return;
        }
        if (candidateHits < STABLE_FRAMES || now < cycleBusyUntil) return;

        TapAccessibilityService service = TapAccessibilityService.instance;
        if (service == null) {
            showStatus("Acessibilidade não conectada");
            return;
        }

        int gap = AppSettings.getGap(this);
        int delay = AppSettings.getLaunchDelay(this);
        if (!service.tapSequence(sequence, width, height, gap)) {
            showStatus("Falha ao enviar os selos");
            return;
        }

        lastAcceptedSequence = sequence;
        lastAcceptedSeenAt = now;
        cycleBusyUntil = now + Math.max(300L, sequence.length() * (long) gap + delay + 180L);
        showStatus("✓ Selos executados: " + sequence);
    }

    private void overlaySequence(String seq) {
        if (overlaySequence != null) {
            handler.post(() -> overlaySequence.setText("Detectado: " + seq));
        }
    }

    private void overlayOcr(String raw) {
        if (overlayOcr == null) return;
        final String shown = raw == null ? "—" : raw.replace("\n", " ").trim();
        handler.post(() -> overlayOcr.setText("OCR viu: " + (shown.isEmpty() ? "—" : shown)));
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL, "Jutsu Auto Clicker", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Controle do leitor automático de jutsus");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private void promoteToForeground(String text) {
        Notification notification = makeNotification(text);
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private Notification makeNotification(String text) {
        Intent open = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 10, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        return builder.setContentTitle("Jutsu Auto Clicker")
                .setContentText(text)
                .setSmallIcon(R.drawable.ic_stat_jutsu)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    private void showStatus(String text) {
        updateNotification(text);
        if (overlayStatus != null) {
            handler.post(() -> {
                overlayStatus.setText(AppSettings.isPaused(this) ? "⏸  PAUSADO" : "●  " + text);
                updateOverlayValues();
            });
        }
    }

    private void updateNotification(String text) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.notify(NOTIFICATION_ID, makeNotification(text));
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }

    private GradientDrawable bg(int color, int radius, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), strokeColor);
        return d;
    }

    private TextView label(String text, float size) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(Color.WHITE);
        v.setTextSize(size);
        v.setGravity(Gravity.CENTER_VERTICAL);
        v.setPadding(dp(8), dp(4), dp(8), dp(4));
        return v;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(11);
        b.setAllCaps(false);
        b.setMinHeight(dp(38));
        b.setPadding(dp(4), 0, dp(4), 0);
        b.setBackground(bg(Color.rgb(28, 24, 58), 11, Color.rgb(90, 65, 150)));
        return b;
    }

    private void showOverlay() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) return;
        if (overlayRoot != null) return;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        overlayRoot = new LinearLayout(this);
        overlayRoot.setOrientation(LinearLayout.VERTICAL);
        overlayRoot.setPadding(dp(7), dp(7), dp(7), dp(7));
        overlayRoot.setBackground(bg(Color.argb(244, 12, 9, 25), 16, Color.rgb(255, 50, 90)));

        FrameLayout handle = new FrameLayout(this);
        handle.setBackground(bg(Color.argb(255, 22, 18, 43), 13, Color.rgb(105, 72, 190)));
        SealLogoView logo = new SealLogoView(this);
        logo.setClickable(false);
        handle.addView(logo, new FrameLayout.LayoutParams(dp(52), dp(52), Gravity.LEFT | Gravity.CENTER_VERTICAL));

        TextView title = label("JutsuAutoClicker  •  v1.3", 13);
        title.setTextColor(Color.WHITE);
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-1, dp(52));
        tp.leftMargin = dp(52);
        handle.addView(title, tp);
        overlayRoot.addView(handle, new LinearLayout.LayoutParams(dp(272), dp(52)));

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(2), dp(5), dp(2), 0);
        panel.setVisibility(overlayExpanded ? View.VISIBLE : View.GONE);

        overlayStatus = label("● Iniciando…", 12);
        overlayStatus.setBackground(bg(Color.argb(180, 24, 20, 45), 9, Color.rgb(70, 55, 120)));
        panel.addView(overlayStatus, new LinearLayout.LayoutParams(-1, dp(34)));

        overlaySequence = label("Detectado: —", 12);
        panel.addView(overlaySequence, new LinearLayout.LayoutParams(-1, dp(32)));

        overlayOcr = label("OCR viu: —", 9);
        overlayOcr.setTextColor(Color.LTGRAY);
        panel.addView(overlayOcr, new LinearLayout.LayoutParams(-1, dp(30)));

        LinearLayout gapRow = valueRow("Intervalo", true);
        panel.addView(gapRow);
        LinearLayout launchRow = valueRow("Lançamento", false);
        panel.addView(launchRow);

        overlayCalibration = label("Calibração: 0 / 0", 10);
        overlayCalibration.setTextColor(Color.LTGRAY);
        panel.addView(overlayCalibration, new LinearLayout.LayoutParams(-1, dp(28)));

        LinearLayout calRow = new LinearLayout(this);
        calRow.setOrientation(LinearLayout.HORIZONTAL);
        addCalButton(calRow, "X−", () -> adjustOffset(true, -0.005f));
        addCalButton(calRow, "X+", () -> adjustOffset(true, 0.005f));
        addCalButton(calRow, "Y−", () -> adjustOffset(false, -0.005f));
        addCalButton(calRow, "Y+", () -> adjustOffset(false, 0.005f));
        addCalButton(calRow, "↺", () -> AppSettings.resetCalibration(this));
        panel.addView(calRow, new LinearLayout.LayoutParams(-1, dp(42)));

        LinearLayout toolsRow = new LinearLayout(this);
        toolsRow.setOrientation(LinearLayout.HORIZONTAL);
        visorButton = button("👁  Visor: EDITAR");
        visorButton.setOnClickListener(v -> toggleVisorEditing());
        Button markers = button("◉  Selos: " + (markersVisible ? "ON" : "OFF"));
        markers.setOnClickListener(v -> { markersVisible = !markersVisible; setMarkersVisible(markersVisible); markers.setText("◉  Selos: " + (markersVisible ? "ON" : "OFF")); });
        toolsRow.addView(visorButton, new LinearLayout.LayoutParams(0, dp(42), 1));
        toolsRow.addView(markers, new LinearLayout.LayoutParams(0, dp(42), 1));
        panel.addView(toolsRow, new LinearLayout.LayoutParams(-1, dp(44)));

        TextView tests = label("TESTAR SELOS", 10);
        tests.setTextColor(Color.rgb(220, 180, 255));
        panel.addView(tests, new LinearLayout.LayoutParams(-1, dp(25)));

        LinearLayout sealRow1 = new LinearLayout(this);
        LinearLayout sealRow2 = new LinearLayout(this);
        sealRow1.setOrientation(LinearLayout.HORIZONTAL);
        sealRow2.setOrientation(LinearLayout.HORIZONTAL);
        addSealButton(sealRow1, 'Z');
        addSealButton(sealRow1, 'V');
        addSealButton(sealRow1, 'X');
        addSealButton(sealRow2, 'B');
        addSealButton(sealRow2, 'C');
        addSealButton(sealRow2, 'N');
        panel.addView(sealRow1, new LinearLayout.LayoutParams(-1, dp(42)));
        panel.addView(sealRow2, new LinearLayout.LayoutParams(-1, dp(42)));

        LinearLayout actionRow = new LinearLayout(this);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        Button launch = button("✦  Lançar");
        launch.setOnClickListener(v -> tapLaunchTest());
        pauseButton = button(AppSettings.isPaused(this) ? "▶ Continuar" : "Ⅱ Pausar");
        pauseButton.setOnClickListener(v -> togglePause());
        Button stop = button("■ Parar");
        stop.setOnClickListener(v -> stopSelf());
        actionRow.addView(launch, new LinearLayout.LayoutParams(0, dp(42), 1));
        actionRow.addView(pauseButton, new LinearLayout.LayoutParams(0, dp(42), 1));
        actionRow.addView(stop, new LinearLayout.LayoutParams(0, dp(42), 1));
        panel.addView(actionRow, new LinearLayout.LayoutParams(-1, dp(44)));

        overlayRoot.addView(panel, new LinearLayout.LayoutParams(dp(272), -2));

        overlayParams = new WindowManager.LayoutParams(
                dp(286), WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        overlayParams.gravity = Gravity.BOTTOM | Gravity.LEFT;
        overlayParams.x = dp(10);
        overlayParams.y = dp(28);

        attachDrag(handle);
        try {
            windowManager.addView(overlayRoot, overlayParams);
            updateOverlayValues();
        } catch (Throwable t) {
            overlayRoot = null;
        }
    }

    private void showOcrVisor() {
        if (windowManager == null || visorView != null) return;
        visorView = new OcrVisorView(this);
        visorView.setListener(new OcrVisorView.Listener() {
            @Override public void onMoveDelta(int dx, int dy) {
                if (visorParams == null) return;
                visorParams.x = clamp(visorParams.x + dx, 0, Math.max(0, width - visorParams.width));
                visorParams.y = clamp(visorParams.y + dy, 0, Math.max(0, height - visorParams.height));
                saveVisorRect();
                try { windowManager.updateViewLayout(visorView, visorParams); } catch (Throwable ignored) { }
            }
            @Override public void onResizeDelta(int dw, int dh) {
                if (visorParams == null) return;
                visorParams.width = clamp(visorParams.width + dw, dp(180), Math.max(dp(180), width - visorParams.x));
                visorParams.height = clamp(visorParams.height + dh, dp(55), Math.max(dp(55), height - visorParams.y));
                saveVisorRect();
                try { windowManager.updateViewLayout(visorView, visorParams); } catch (Throwable ignored) { }
            }
        });
        int x = (int)(width * AppSettings.getOcrLeft(this));
        int y = (int)(height * AppSettings.getOcrTop(this));
        int w = Math.max(dp(180), (int)(width * (AppSettings.getOcrRight(this)-AppSettings.getOcrLeft(this))));
        int h = Math.max(dp(55), (int)(height * (AppSettings.getOcrBottom(this)-AppSettings.getOcrTop(this))));
        visorParams = new WindowManager.LayoutParams(w, h,
                Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        visorParams.gravity = Gravity.TOP | Gravity.LEFT;
        visorParams.x = x; visorParams.y = y;
        try { windowManager.addView(visorView, visorParams); } catch (Throwable ignored) { visorView = null; }
    }

    private void saveVisorRect() {
        if (visorParams == null || width <= 0 || height <= 0) return;
        float l = visorParams.x/(float)width, t = visorParams.y/(float)height;
        float r = (visorParams.x+visorParams.width)/(float)width, b = (visorParams.y+visorParams.height)/(float)height;
        AppSettings.setOcrRect(this,l,t,r,b);
    }

    private void toggleVisorEditing() {
        if (visorView == null || visorParams == null) return;
        visorEditing = !visorEditing;
        int flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        if (!visorEditing) flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        visorParams.flags = flags;
        try { windowManager.updateViewLayout(visorView, visorParams); } catch (Throwable ignored) { }
        if (visorButton != null) visorButton.setText(visorEditing ? "👁  Visor: EDITAR" : "🔒  Visor: TRAVADO");
        showStatus(visorEditing ? "Arraste o visor para VBZXZV" : "Visor travado • OCR ativo");
    }

    private void showSealMarkers() {
        if (windowManager == null || markerView != null) return;
        markerView = new SealMarkerView(this);
        markerView.setScreenSize(width,height);
        markerParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        markerParams.gravity = Gravity.TOP | Gravity.LEFT;
        try { windowManager.addView(markerView, markerParams); } catch (Throwable ignored) { markerView = null; }
    }

    private void setMarkersVisible(boolean visible) {
        if (markerView != null) markerView.setVisibility(visible ? View.VISIBLE : View.GONE);
        showStatus(visible ? "Marcadores dos selos ligados" : "Marcadores dos selos ocultos");
    }

    private LinearLayout valueRow(String name, boolean gap) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        TextView left = label(name, 11);
        TextView value = label("", 11);
        Button minus = button("−");
        Button plus = button("+");
        if (gap) {
            overlaySpeed = value;
            minus.setOnClickListener(v -> { AppSettings.setGap(this, AppSettings.getGap(this) - 2); updateOverlayValues(); });
            plus.setOnClickListener(v -> { AppSettings.setGap(this, AppSettings.getGap(this) + 2); updateOverlayValues(); });
        } else {
            overlayLaunch = value;
            minus.setOnClickListener(v -> { AppSettings.setLaunchDelay(this, AppSettings.getLaunchDelay(this) - 10); updateOverlayValues(); });
            plus.setOnClickListener(v -> { AppSettings.setLaunchDelay(this, AppSettings.getLaunchDelay(this) + 10); updateOverlayValues(); });
        }
        row.addView(left, new LinearLayout.LayoutParams(dp(74), dp(40)));
        row.addView(minus, new LinearLayout.LayoutParams(dp(44), dp(40)));
        row.addView(value, new LinearLayout.LayoutParams(0, dp(40), 1));
        row.addView(plus, new LinearLayout.LayoutParams(dp(44), dp(40)));
        return row;
    }

    private void addCalButton(LinearLayout row, String text, Runnable action) {
        Button b = button(text);
        b.setOnClickListener(v -> { action.run(); updateOverlayValues(); });
        row.addView(b, new LinearLayout.LayoutParams(0, dp(40), 1));
    }

    private void addSealButton(LinearLayout row, final char seal) {
        Button b = button(String.valueOf(seal));
        b.setTextSize(14);
        b.setOnClickListener(v -> {
            TapAccessibilityService s = TapAccessibilityService.instance;
            if (s != null) s.tapSingle(seal, width, height);
            showStatus("Teste: selo " + seal);
        });
        row.addView(b, new LinearLayout.LayoutParams(0, dp(40), 1));
    }

    private void tapLaunchTest() {
        TapAccessibilityService s = TapAccessibilityService.instance;
        if (s != null) s.tapLaunch(width, height);
        showStatus("Teste: lançamento");
    }

    private void togglePause() {
        boolean paused = !AppSettings.isPaused(this);
        AppSettings.setPaused(this, paused);
        if (!paused) {
            candidateSequence = "";
            candidateHits = 0;
            lastAcceptedSequence = "";
        }
        if (pauseButton != null) pauseButton.setText(paused ? "▶ Continuar" : "Ⅱ Pausar");
        showStatus(paused ? "Pausado" : "Continuando…");
    }

    private void adjustOffset(boolean horizontal, float delta) {
        if (horizontal) AppSettings.setOffsetX(this, AppSettings.getOffsetX(this) + delta);
        else AppSettings.setOffsetY(this, AppSettings.getOffsetY(this) + delta);
    }

    private void updateOverlayValues() {
        if (overlaySpeed != null) overlaySpeed.setText(AppSettings.getGap(this) + " ms");
        if (overlayLaunch != null) overlayLaunch.setText(AppSettings.getLaunchDelay(this) + " ms");
        if (overlayCalibration != null) {
            overlayCalibration.setText(String.format(Locale.US, "Calibração: X %+.1f%%   Y %+.1f%%",
                    AppSettings.getOffsetX(this) * 100f, AppSettings.getOffsetY(this) * 100f));
        }
        if (pauseButton != null) pauseButton.setText(AppSettings.isPaused(this) ? "▶ Continuar" : "Ⅱ Pausar");
    }

    private void attachDrag(View handle) {
        handle.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            boolean moved;

            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX();
                        downY = e.getRawY();
                        startX = overlayParams.x;
                        startY = overlayParams.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - downX;
                        float dy = e.getRawY() - downY;
                        if (Math.abs(dx) > dp(5) || Math.abs(dy) > dp(5)) moved = true;
                        if (moved && windowManager != null && overlayRoot != null) {
                            overlayParams.x = Math.max(0, startX + (int) dx);
                            overlayParams.y = Math.max(0, startY - (int) dy);
                            try { windowManager.updateViewLayout(overlayRoot, overlayParams); } catch (Throwable ignored) { }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) toggleExpanded();
                        return true;
                    default:
                        return true;
                }
            }
        });
    }

    private void toggleExpanded() {
        if (overlayRoot == null || overlayRoot.getChildCount() < 2) return;
        View panel = overlayRoot.getChildAt(1);
        overlayExpanded = !overlayExpanded;
        panel.setVisibility(overlayExpanded ? View.VISIBLE : View.GONE);
        try { windowManager.updateViewLayout(overlayRoot, overlayParams); } catch (Throwable ignored) { }
    }

    private boolean SettingsCanDrawOverlays() {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
    }

    private String safeMessage(Throwable t) {
        String m = t.getMessage();
        return m == null ? t.getClass().getSimpleName() : m;
    }

    private void removeOverlay() {
        if (windowManager != null && visorView != null) {
            try { windowManager.removeView(visorView); } catch (Throwable ignored) { }
        }
        if (windowManager != null && markerView != null) {
            try { windowManager.removeView(markerView); } catch (Throwable ignored) { }
        }
        visorView = null; visorParams = null; markerView = null; markerParams = null;
        if (windowManager != null && overlayRoot != null) {
            try { windowManager.removeView(overlayRoot); } catch (Throwable ignored) { }
        }
        overlayRoot = null;
        overlayStatus = null;
        overlaySequence = null;
        overlayOcr = null;
        overlaySpeed = null;
        overlayLaunch = null;
        overlayCalibration = null;
        pauseButton = null;
        visorButton = null;
    }

    private void stopCaptureOnly() {
        if (reader != null) {
            try { reader.setOnImageAvailableListener(null, null); } catch (Throwable ignored) { }
            try { reader.close(); } catch (Throwable ignored) { }
            reader = null;
        }
        if (display != null) {
            try { display.release(); } catch (Throwable ignored) { }
            display = null;
        }
        if (projection != null) {
            try {
                if (projectionCallback != null) projection.unregisterCallback(projectionCallback);
            } catch (Throwable ignored) { }
            try { projection.stop(); } catch (Throwable ignored) { }
            projection = null;
        }
        projectionCallback = null;
        busy = false;
    }

    @Override public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        stopCaptureOnly();
        removeOverlay();
        if (recognizer != null) {
            try { recognizer.close(); } catch (Throwable ignored) { }
            recognizer = null;
        }
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.cancel(NOTIFICATION_ID);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
