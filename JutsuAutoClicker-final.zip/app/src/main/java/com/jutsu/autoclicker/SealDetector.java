package com.jutsu.autoclicker;

import com.google.mlkit.vision.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Validação do texto OCR. O minijogo aceita somente os selos V, B, Z, X, C e N.
 * A lógica é separada do serviço para ser facilmente testada sem Android.
 */
public final class SealDetector {
    private static final Pattern VALID = Pattern.compile("[VBZXCN]{2,12}");

    private SealDetector() {}

    public static String findSequence(Text text) {
        if (text == null) return null;
        String best = findSequenceInPlainText(text.getText());
        for (Text.TextBlock block : text.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                String candidate = findSequenceInPlainText(line.getText());
                best = better(best, candidate);
            }
        }
        return best;
    }

    /** Função pública para testes e para diagnóstico offline. */
    public static String findSequenceInPlainText(String raw) {
        if (raw == null) return null;
        String upper = raw.toUpperCase(Locale.US)
                .replace('Á', 'A').replace('Â', 'A').replace('Ã', 'A')
                .replace('É', 'E').replace('Ê', 'E').replace('Í', 'I')
                .replace('Ó', 'O').replace('Ô', 'O').replace('Õ', 'O')
                .replace('Ú', 'U').replace('Ç', 'C');

        List<String> tokens = new ArrayList<>();
        Matcher m = Pattern.compile("[A-Z0-9]+").matcher(upper);
        while (m.find()) tokens.add(normalizeToken(m.group()));

        String best = null;
        // Caso normal: VBZXZV em um único token.
        for (String token : tokens) {
            if (isValid(token)) best = better(best, token);
        }

        // OCR às vezes separa as letras: V B Z X Z V.
        StringBuilder singles = new StringBuilder();
        for (String token : tokens) {
            if (token.length() == 1 && allSealChars(token)) {
                char c = token.charAt(0);
                singles.append(c);
                if (singles.length() >= 2) {
                    String s = singles.toString();
                    if (isValid(s)) best = better(best, s);
                }
            } else {
                singles.setLength(0);
            }
        }

        // OCR também pode retornar blocos como VB + ZXZV.
        for (int i = 0; i < tokens.size(); i++) {
            StringBuilder join = new StringBuilder();
            for (int j = i; j < Math.min(tokens.size(), i + 6); j++) {
                String token = tokens.get(j);
                if (!allSealChars(token)) break;
                if (token.length() > 12) break;
                join.append(token);
                if (isValid(join.toString())) best = better(best, join.toString());
            }
        }
        return best;
    }

    public static String normalizeToken(String token) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < token.length(); i++) {
            char c = token.charAt(i);
            switch (c) {
                // Confusões comuns do OCR para a fonte do minijogo.
                case 'Y': c = 'V'; break;
                case 'K': c = 'X'; break;
                case 'Q': c = 'Z'; break;
                case '2': c = 'Z'; break;
                case '8': c = 'B'; break;
                case '6': c = 'C'; break;
                case '0': c = 'O'; break;
                case '1': c = 'I'; break;
                default: break;
            }
            out.append(c);
        }
        return out.toString();
    }

    public static boolean isValid(String s) {
        return s != null && VALID.matcher(s).matches();
    }

    public static boolean allSealChars(String s) {
        if (s == null || s.isEmpty()) return false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if ("VBZXCN".indexOf(c) < 0) return false;
        }
        return true;
    }

    private static String better(String current, String candidate) {
        if (candidate == null) return current;
        if (current == null || candidate.length() > current.length()) return candidate;
        return current;
    }
}
