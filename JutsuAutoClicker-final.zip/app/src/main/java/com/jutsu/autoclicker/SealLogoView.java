package com.jutsu.autoclicker;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/** Pequeno emblema inspirado em selos de mão, desenhado sem recursos externos. */
public class SealLogoView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    public SealLogoView(Context context) {
        super(context);
    }

    @Override protected void onDraw(Canvas c) {
        float d = getResources().getDisplayMetrics().density;
        float cx = getWidth() / 2f, cy = getHeight() / 2f;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(3 * d);
        p.setColor(Color.rgb(255, 55, 90));
        p.setStrokeCap(Paint.Cap.ROUND);

        Path hand = new Path();
        hand.moveTo(cx, cy + 24*d);
        hand.lineTo(cx - 8*d, cy + 4*d);
        hand.lineTo(cx - 18*d, cy - 10*d);
        hand.moveTo(cx, cy + 24*d);
        hand.lineTo(cx + 8*d, cy + 4*d);
        hand.lineTo(cx + 18*d, cy - 10*d);
        hand.moveTo(cx - 5*d, cy + 18*d);
        hand.lineTo(cx - 20*d, cy + 2*d);
        hand.moveTo(cx + 5*d, cy + 18*d);
        hand.lineTo(cx + 20*d, cy + 2*d);
        hand.moveTo(cx - 12*d, cy - 2*d);
        hand.lineTo(cx, cy - 22*d);
        hand.lineTo(cx + 12*d, cy - 2*d);
        c.drawPath(hand, p);

        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.argb(40, 255, 55, 90));
        c.drawCircle(cx, cy, 30*d, p);
    }
}
