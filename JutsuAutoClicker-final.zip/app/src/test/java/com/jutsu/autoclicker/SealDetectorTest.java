package com.jutsu.autoclicker;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class SealDetectorTest {
    @Test public void aceitaSequenciaNormal() {
        assertEquals("VBZXZV", SealDetector.findSequenceInPlainText("Coroa Agonizante - VBZXZV"));
    }

    @Test public void aceitaLetrasSeparadas() {
        assertEquals("VBZXZV", SealDetector.findSequenceInPlainText("V B Z X Z V"));
    }

    @Test public void aceitaBlocosSeparados() {
        assertEquals("VBZXZV", SealDetector.findSequenceInPlainText("VB ZXZV"));
        assertEquals("ZVBXCXCZ", SealDetector.findSequenceInPlainText("Coroa das Chamas - ZVBXCXCZ"));
        assertEquals("ZVBXCXCZ", SealDetector.findSequenceInPlainText("Z V B X C X C Z"));
        assertEquals("ZVBCNXZCVBN", SealDetector.findSequenceInPlainText("ZVBCNXZCVBN"));
    }

    @Test public void corrigeErrosComunsDoOcr() {
        assertEquals("VBZXZV", SealDetector.findSequenceInPlainText("Y 8 Z K 2 Y"));
    }

    @Test public void rejeitaTextoSemSelos() {
        assertNull(SealDetector.findSequenceInPlainText("Coroa Agonizante"));
    }

    @Test public void validaSomenteSeisSelos() {
        assertTrue(SealDetector.isValid("VBZXZV"));
        assertTrue(!SealDetector.isValid("VBTX"));
    }
}
